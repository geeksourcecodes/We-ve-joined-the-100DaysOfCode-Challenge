# 100 Days Of Code - Logbuch

### Tag 0: 20. Februar 2016 (Beispiel 1)
##### (lösche oder kommentiere mich aus)

**Heutiger Fortschritt**: CSS Korrektur, Arbeit an der Canvas Funktionalität der App.

**Gedanken:** Ich habe mich wirklich schwer getan mit CSS, aber alles in Allem habe ich das Gefühl, ich werde langsam besser darin. Canvas ist noch immer Neuland für mich, aber ich habe es geschafft einen Teil der grundlegenden Funktionalität zu verstehen.

**Link zur Arbeit:** [Taschenrechner App](http://www.example.com)

### Tag 1: 21. Februar 2016
##### (lösche mich oder kommentiere mich aus)

**Heutiger Fortschritt**: CSS Korrektur, Arbeit an der Canvas Funktionalität der App.

**Gedanken:** Ich habe mich wirklich schwer getan mit CSS/ wirklich mit CSS gekämpft, aber alles in allem habe ich das Gefühl, ich werde langsam besser darin. Canvas ist noch immer Neuland für mich, aber ich habe es geschafft einen Teil der grundlegenden Funktionalität zu verstehen.

**Link zur Arbeit:** [Taschenrechner App](http://www.example.com)


### Tag 1: Montag, 27. Juni (Beispiel 2)

**Heutiger Fortschritt**: Ich bin einige Übungen auf freeCodeCamp durchgegangen.

**Gedanken** Ich habe vor Kurzem mit dem Coden begonnen, und es ist ein tolles Gefühl, wenn ich nach vielfachen Ansätzen und mehreren investierten Stunden endlich einen Algorithmus gelöst bekomme.

**Link(s) zur Arbeit**
1. [Find the Longest Word in a String](https://www.freecodecamp.com/challenges/find-the-longest-word-in-a-string)
2. [Title Case a Sentence](https://www.freecodecamp.com/challenges/title-case-a-sentence)