# #100DaysOfCode Log - Runde 1 - [Dein Name]

Das Logbuch meiner #100DaysOfCode Challenge. Begonnen am [Montag, 17. Juli 2017].

## Log

### R1D1 
Habe mit einem Wetter App Projekt begonnen. Habe am Skizzen Layout der App gearbeitet, hatte etwas Schwierigkeiten mit der OpenWeather API http://www.example.com

### R1D2
