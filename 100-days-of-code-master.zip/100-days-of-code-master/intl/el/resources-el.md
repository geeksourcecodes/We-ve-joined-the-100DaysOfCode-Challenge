# Κύριοι πόροι για τις #100ΗμέρεςΚώδικα

_[ΣτΜ.: Οι πόροι που διατίθενται είναι στα αγγλικά.]_

[Το επίσημο σάιτ για τις #100ΗμέρεςΚώδικα](http://100daysofcode.com/)

### Άρθρα

1. [Join the #100DaysOfCode](https://medium.freecodecamp.com/join-the-100daysofcode-556ddb4579e4) freeCodeCamp Medium
2. [Boot Up 2017 with the #100DaysOfCode Challenge](https://medium.freecodecamp.com/start-2017-with-the-100daysofcode-improved-and-updated-18ce604b237b) freeCodeCamp Medium
3. [Resistance, Habit Change and the #100DaysOfCode Movement](https://studywebdevelopment.com/100-days-of-code.html) StudyWebDevelopment Blog

### Podcast

# Επιπλέον πόροι για τις #100ΗμέρεςΚώδικα

## Βοηθητικά Άρθρα
1. [Gentle Explanation of 'this keyword in JavaScript](http://rainsoft.io/gentle-explanation-of-this-in-javascript/)

## Projects και Ιδέες
1. [FreeCodeCamp](https://www.freecodecamp.com)
2. [The Odin Project](http://www.theodinproject.com/)

## Άλλοι πόροι
1. [CodeNewbie - #100DaysOfCode Slack Channel](https://codenewbie.typeform.com/to/uwsWlZ)

## Βιβλία (προγραμματιστικά και μη)

### Μη-προγραμματιστικά
1. ["The War of Art" του Steven Pressfield](http://www.goodreads.com/book/show/1319.The_War_of_Art)
2. ["The Obstacle is the Way" του Ryan Holiday](http://www.goodreads.com/book/show/18668059-the-obstacle-is-the-way?ac=1&from_search=true)
3. ["Ego is the Enemy" του Ryan Holiday](http://www.goodreads.com/book/show/27036528-ego-is-the-enemy?from_search=true&search_version=service)
4. ["Meditations" του Marcus Aurelius](https://www.goodreads.com/book/show/662925.Meditations)

### Προγραμματιστικά
1. "Professional Node.js" του Teixeira
2. ["Eloquent Javascript" του Marijn Haverbeke](http://eloquentjavascript.net/) - διαθέσιμο online (δωρεάν) & ως κανονικό βιβλίο
3. "Mastering JavaScript" του Ved Antani

## Περιεχόμενα
* [Κανόνες](rules-el.md)
* [Ημερολόγιο - κλίκαρε εδώ για να δεις την πρόοδό μου](log-el.md)
* [FAQ](FAQ-el.md)
* [Πόροι](resources-el.md)
