# # 100DaysOfCode Log - 第一轮 - [你的名字]

我的 #100DaysOfCode 挑战日志。 [2017年7月17日，周一] 开始。

## 日志

### R1D1 （第一轮第一天）
开始了天气app。在app的layout的草稿上工作，有点在 OpenWeather API http://www.example.com 卡住。

### R1D2 （第一轮第二天）
