# #100DaysOfCode 学習ログ - 1週目 - [自分の名前]

私の#100DaysOfCodeチャレンジの学習ログです。2017年6月17日開始。

## 学習ログ

### R1D1
天気アプリの開発を開始。アプリの大まかなレイアウトができてきたが、OpenWeatherのAPIの扱いに苦労した。 http://www.example.com

### R1D2
