# #100DaysOfCode Log - Round 1 - [Your Name Here]

The log of my #100DaysOfCode challenge. Started on [July 17, Monday, 2017].

## Log

### R1D1 
Started a Weather App. Worked on the draft layout of the app, struggled with OpenWeather API http://www.example.com

### R1D2
