# 100 Days Of Code - Registre

### Day 0: 30 de Febrer de 2018 (exemple 1)
##### (esborra o comenta-ho)

**Progrés d'avui**: He corregit codi CSS, he treballat en la funcionalitat del canvas per una app.

**Reflexions:** He tingut dificultats amb el CSS però tinc la sensació que vaig millorant poc a poc. El Canvas és molt nou per mi, però crec que me les he arreglat per donar-li una funcionalitat bàsica.

**Enllaç a la feina:** [App Calculadora](http://www.example.com)

### Day 0: 30 de Febrer de 2018 (exemple 1)
##### (esborra o comenta-ho)

**Progrés d'avui**: He corregit codi CSS, he treballat en la funcionalitat del canvas per una app.

**Reflexions:** He tingut dificultats amb el CSS però tinc la sensació que vaig millorant poc a poc. El Canvas és molt nou per mi, però crec que me les he arreglat per donar-li una funcionalitat bàsica.

**Enllaç a la feina:** [App Calculadora](http://www.example.com)

### Day 1: Dilluns 27 de Juny de 2018

**Progrés d'avui**: I've gone through many exercises on FreeCodeCamp.

**Reflexions:** I've recently started coding, and it's a great feeling when I finally solve an algorithm challenge after a lot of attempts and hours spent.

**Enllaç(os) a la meva feina**
1. [Troba la paraula més llarga en un string](https://www.freecodecamp.com/challenges/find-the-longest-word-in-a-string)
2. [Majúscules al inici de cada paraula](https://www.freecodecamp.com/challenges/title-case-a-sentence)
