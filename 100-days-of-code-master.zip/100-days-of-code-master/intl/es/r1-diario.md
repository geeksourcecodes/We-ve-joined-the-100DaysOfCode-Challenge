# #100DaysOfCode diario - ronda 1 - [ponga su nombre aquí]

El diario de mi reto #100DaysOfCode. Empecé el [17 de julio, lunes, 2017]

## Registro

### R1D1

Empecé una aplicación de clima. Trabajé en el diseño gráfico de la aplicación. El API de OpenWeather fue una prueba http://www.example.com.

### R1D2
