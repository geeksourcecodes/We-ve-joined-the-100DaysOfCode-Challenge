# 100 días de código - diario

### Día 0: 30 de febrero de 2016 (ejemplo 1)

##### (elimine o comente)

**Progreso de hoy**: Arreglé CSS y trabajé en funciones de canvas por el app.

**Reflexiones:** Trabajando con el CSS fue una prueba pero, en general, siento que estoy progresando y mejorando lentamente. Canvas, todavía es nuevo para mi pero logré descubrir algunas funcionalidades básicas.  
**Enlace a mi trabajo:** [Calculadora App](http://www.example.com)

### Día 0: 30 de febrero de 2016 (ejemplo 1)

##### (elimine o comente)

**Progreso de hoy**: Arreglé CSS y trabajé en funciones de canvas por el app.

**Reflexiones:** Trabajando con el CSS fue una prueba pero, en general, siento que estoy progresando y mejorando lentamente. Canvas, todavía es nuevo para mi pero logré descubrir algunas funcionalidades básicas.  
**Enlace a mi trabajo:** [Calculadora App](http://www.example.com)

### día 1: 27 de junio, 2016

**Progreso de hoy**: He completado muchos ejercicios en FreeCodeCamp.

**Reflexiones** Recientemente comencé a programar y es una gran sensación cuando finalmente resuelvo un desafío de algoritmo después de muchos intentos y horas.  
**Enlace(s) a mi trabajo**

1.  [Descubra la palabra más larga en una cadena de caracteres](https://www.freecodecamp.com/challenges/find-the-longest-word-in-a-string)
2.  [Poner título en mayúsculas en una oración](https://www.freecodecamp.com/challenges/title-case-a-sentence)
