# #100DaysOfCode Log - Round 1 - [Il tuo nome qui]

Log della mia #100DaysOfCode challenge. Iniziata il [18 Gennaio 2019].

## Log

### R1D1 
Iniziata una app per il meteo. Ho lavorato sulla bozza per il layout e sono impazzito con le API di OpenWeather http://www.example.com

### R1D2
