# 100 Days Of Code - Log

### Giorno 0: 18 Gennaio 2019 (Esempio 1)
##### (cancellami o commentami)

**Progressi di oggi**: Fixati CSS, lavorato alle canvas per l'app.

**Appunti:** Ho avuto veramemte difficoltà con i CSS, ma, tutto sommato, mi sembra di essere un po' migliorato. Le Canvas sono nuovissime per me, ma sono riuscito a capirne qualche funzionalità di base.

**Link al lavoro:** [Calculator App](http://www.example.com)

### Giorno 0: 18 Gennaio 2019 (Esempio 2)
##### (cancellami o commentami)

**Progressi di oggi**: Fixati CSS, lavorato alle canvas per l'app.

**Appunti:** Ho avuto veramemte difficoltà con i CSS, ma, tutto sommato, mi sembra di essere un po' migliorato. Le Canvas sono nuovissime per me, ma sono riuscito a capirne qualche funzionalità di base.

**Link al lavoro:** [Calculator App](http://www.example.com)


**Link al lavoro:** [Calculator App](http://www.example.com)

### Giorno 1: 18 Gennaio 2019 (Esempio 2)

**Progressi di oggi**: Fixati CSS, lavorato alle canvas per l'app.

**Appunti:** Ho avuto veramemte difficoltà con i CSS, ma, tutto sommato, mi sembra di essere un po' migliorato. Le Canvas sono nuovissime per me, ma sono riuscito a capirne qualche funzionalità di base.

**Link al lavoro:**
1. [Find the Longest Word in a String](https://www.freecodecamp.com/challenges/find-the-longest-word-in-a-string)
2. [Title Case a Sentence](https://www.freecodecamp.com/challenges/title-case-a-sentence)
