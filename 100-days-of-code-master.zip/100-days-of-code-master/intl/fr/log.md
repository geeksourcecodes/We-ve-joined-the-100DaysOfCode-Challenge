# 100 Jours de Code - Log

### Jour 0: 26 Février 2016
##### (supprimer ou commenter l'exemple)

**Progrès**: Correction du CSS, avancement de la fonctionnalité canvas dans l'app

**Pensées**: J'ai vraiment bataillé avec le CSS, mais, dans l'ensemble, j'ai l'impression que je commence à m'améliorer. Canvas est encore un concept nouveau pour moi, mais j'ai réussi à comprendre des fonctionnalités de base.

**Lien vers les travaux**: [Calculator App](http://www.example.com)

### Jour 1: 27 février 2016
##### (supprimer ou commenter l'exemple)

**Progrès**: J'ai complété des exercices surFreeCodeCamp.

**Pensées**: J'ai commencé à coder récemment, et c'est vraiment super quand je parviens à résoudre un exercice d'algorithme après de nombreux essais et des heures passées dessus.

**Liens vers les travaux**:
1. [Find the Longest Word in a String](https://www.freecodecamp.com/challenges/find-the-longest-word-in-a-string) 
2. [Title Case a Sentence](https://www.freecodecamp.com/challenges/title-case-a-sentence) 
